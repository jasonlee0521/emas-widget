# EMAS Widget A — 手机云端编译

这个项目用于生成可安装的 Android APK。当前 A 版是 e.MAS 启动快捷入口 Widget，不代表已经实现未经官方验证的车辆直控 API。

## 手机操作
1. 在 GitHub 新建一个空的 Public repository。
2. 把本项目里的所有文件上传到仓库根目录（`.github/workflows/build.yml` 也要上传）。
3. 上传完成后打开仓库的 **Actions**。
4. 选择 **Build APK**。
5. 点 **Run workflow**；如果已经自动运行，直接打开最新一次运行。
6. 等待绿色成功标记后，在页面底部 **Artifacts** 下载 `EMAS-Widget-debug`。
7. 解压得到 `app-debug.apk`，在 Android 手机上安装。

如果 GitHub 手机网页不方便上传文件，可以先在手机文件管理器里解压本项目 ZIP，再选择项目内全部文件上传。
