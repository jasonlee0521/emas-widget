package com.emas.widget;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class MainActivity extends Activity {
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  TextView t=new TextView(this);
  t.setPadding(32,64,32,32); t.setTextSize(18);
  t.setText("EMAS Widget A\n\nAdd the widget to your home screen.\nButtons open the corresponding e.MAS area.");
  setContentView(t);
 }
}
