package com.emas.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.RemoteViews;
import android.widget.Toast;

public class EmasWidgetProvider extends AppWidgetProvider {
 private static final String ACTION="com.emas.widget.A";
 private static final String PKG="com.malaysia.emas";

 @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids){
  for(int id:ids) update(c,m,id);
 }
 private void update(Context c, AppWidgetManager m, int id){
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
  v.setTextViewText(R.id.model,"e.MAS • Quick access");
  v.setTextViewText(R.id.battery,"Battery  —");
  v.setTextViewText(R.id.detail,"Charging  •  Temperature —");
  String[] cmds={"lock","unlock","ac","window","charge","position","flash","refresh"};
  int[] views={R.id.lock,R.id.unlock,R.id.ac,R.id.window,R.id.charge,R.id.position,R.id.flash,R.id.refresh};
  for(int i=0;i<views.length;i++){
   Intent x=new Intent(c,EmasWidgetProvider.class).setAction(ACTION).putExtra("cmd",cmds[i]);
   PendingIntent p=PendingIntent.getBroadcast(c,100+i,x,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   v.setOnClickPendingIntent(views[i],p);
  }
  m.updateAppWidget(id,v);
 }
 @Override public void onReceive(Context c,Intent i){
  super.onReceive(c,i);
  if(!ACTION.equals(i.getAction())) return;
  String cmd=i.getStringExtra("cmd");
  if("refresh".equals(cmd)){ Toast.makeText(c,"已刷新",Toast.LENGTH_SHORT).show(); return; }
  if(!isInstalled(c)){ Toast.makeText(c,"请先安装 Proton e.MAS",Toast.LENGTH_SHORT).show(); return; }
  // Conservative A version: launch the official e.MAS app. No private
  // authentication or undocumented vehicle API is copied into this widget.
  Intent launch=c.getPackageManager().getLaunchIntentForPackage(PKG);
  if(launch==null){
   launch=new Intent(Intent.ACTION_MAIN);
   launch.addCategory(Intent.CATEGORY_LAUNCHER);
   launch.setPackage(PKG);
  }
  if(launch!=null){
   launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
   launch.setData(Uri.parse("emas://remote-control?feature="+cmd));
   try{ c.startActivity(launch); }
   catch(Exception e){ launch.setData(null); c.startActivity(launch); }
  }
 }
 private boolean isInstalled(Context c){
  try{ c.getPackageManager().getPackageInfo(PKG,0); return true; }catch(Exception e){ return false; }
 }
}
